// Testing the gdb compiler

#include <stdio.h>
#include <string.h>

int main(){

    char* p;

    strcpy(p, "I'm a string!");

    printf("Hello world\n")
    
    printf("%s\n", p);
    printf("I'm the location of the string: %d\n", *p);

    return 0;
}